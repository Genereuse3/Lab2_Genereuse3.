#!/usr/bin/env bash
# ==============================================================================
# Script Name: organizer.sh
# Purpose:     Automates the archiving of course grade data and resets the workspace
# Lab:         Lab 2 - ALU Transcript Generator
# Author:      Genereuse3
# ==============================================================================

set -o errexit
set -o nounset
set -o pipefail

# Configuration
SOURCE_FILE="grades.csv"
ARCHIVE_DIR="archive"
LOG_FILE="organizer.log"

echo "=== Grade File Organizer ==="

# Step 1: Ensure Archive Directory exists
if [ ! -d "$ARCHIVE_DIR" ]; then
    echo "[INFO] Archive directory '$ARCHIVE_DIR' not found. Creating it..."
    mkdir -p "$ARCHIVE_DIR"
    echo "[SUCCESS] Created directory: $ARCHIVE_DIR"
else
    echo "[INFO] Archive directory '$ARCHIVE_DIR' already exists."
fi

# Step 2: Validate that source file exists
if [ ! -f "$SOURCE_FILE" ]; then
    echo "[ERROR] Source file '$SOURCE_FILE' does not exist in the current directory." >&2
    echo "[ERROR] Operation aborted. No files were archived." >&2
    exit 1
fi

# Step 3: Generate timestamp and destination filename
# Required format example from specifications: grades_20251105-170000.csv
TIMESTAMP=$(date +"%Y%m%d-%H%M%S")
HUMAN_TIMESTAMP=$(date +"%Y-%m-%d %H:%M:%S")
ARCHIVED_FILENAME="grades_${TIMESTAMP}.csv"
DESTINATION_PATH="${ARCHIVE_DIR}/${ARCHIVED_FILENAME}"

# Step 4: Archival Process - Rename and move existing grades.csv
echo "[INFO] Moving '$SOURCE_FILE' to '$DESTINATION_PATH'..."
mv "$SOURCE_FILE" "$DESTINATION_PATH"
echo "[SUCCESS] Successfully archived '$SOURCE_FILE' as '$DESTINATION_PATH'."

# Step 5: Workspace Reset - Create new empty grades.csv
echo "[INFO] Resetting workspace by creating a fresh empty '$SOURCE_FILE'..."
touch "$SOURCE_FILE"
echo "[SUCCESS] Fresh empty '$SOURCE_FILE' created and ready for next batch."

# Step 6: Logging - Append operation details to organizer.log
# Details required: timestamp, original filename, and new archived filename
LOG_ENTRY="[${HUMAN_TIMESTAMP}] Operation: ARCHIVE | Original: ${SOURCE_FILE} | Archived: ${DESTINATION_PATH}"
echo "$LOG_ENTRY" >> "$LOG_FILE"
echo "[SUCCESS] Logged operation to '$LOG_FILE'."

echo "=== Organizer completed successfully ==="
