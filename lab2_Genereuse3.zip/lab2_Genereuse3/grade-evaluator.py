#!/usr/bin/env python3
"""
ALU Transcript Generator (Lab 2)
Course: Introduction to Python Programming and Databases
Institution: African Leadership University

This script evaluates student grades from a CSV file, performs strict validation
on scores and weights, calculates GPA based on ALU's weighted system, determines
Pass/Fail academic standing, and identifies formative assignments eligible for
resubmission.
"""

import csv
import sys
import os


def load_csv_data(filename=None):
    """
    Prompts the user for a filename (or uses the passed parameter), checks if it exists,
    and extracts all fields into a list of dictionaries with robust error handling.
    """
    if filename is None:
        filename = input("Enter the name of the CSV file to process (e.g., grades.csv): ").strip()
    
    if not filename:
        print("Error: Filename cannot be empty. Please provide a valid file path (e.g., grades.csv).")
        sys.exit(1)

    if not os.path.exists(filename):
        print(f"Error: The file '{filename}' was not found.")
        sys.exit(1)
        
    assignments = []
    required_fields = {'assignment', 'group', 'score', 'weight'}
    
    try:
        with open(filename, mode='r', encoding='utf-8') as file:
            reader = csv.DictReader(file)
            
            if not reader.fieldnames:
                print(f"Error: The file '{filename}' is empty or missing headers.")
                sys.exit(1)
                
            # Verify required columns exist
            fieldnames_normalized = {fn.strip().lower() for fn in reader.fieldnames if fn}
            if not required_fields.issubset(fieldnames_normalized):
                missing = required_fields - fieldnames_normalized
                print(f"Error: Missing required column(s) in CSV: {', '.join(sorted(missing))}")
                print(f"Found headers: {reader.fieldnames}")
                print("Required headers: assignment, group, score, weight")
                sys.exit(1)
                
            for line_num, row in enumerate(reader, start=2):
                assignment_name = row.get('assignment', '').strip()
                group_name = row.get('group', '').strip()
                score_raw = row.get('score', '').strip()
                weight_raw = row.get('weight', '').strip()

                if not assignment_name:
                    print(f"Error: Line {line_num}: 'assignment' name cannot be empty.")
                    sys.exit(1)

                if not group_name:
                    print(f"Error: Line {line_num}: 'group' cannot be empty for assignment '{assignment_name}'.")
                    sys.exit(1)

                # Convert numeric fields to floats with specific error guidance
                try:
                    score = float(score_raw)
                except ValueError:
                    print(f"Error: Line {line_num}: Invalid score '{score_raw}' for '{assignment_name}'. Expected a numeric value (0-100).")
                    sys.exit(1)

                try:
                    weight = float(weight_raw)
                except ValueError:
                    print(f"Error: Line {line_num}: Invalid weight '{weight_raw}' for '{assignment_name}'. Expected a numeric value.")
                    sys.exit(1)

                assignments.append({
                    'assignment': assignment_name,
                    'group': group_name,
                    'score': score,
                    'weight': weight
                })

        if not assignments:
            print(f"Error: The file '{filename}' contains no data rows.")
            sys.exit(1)

        return assignments

    except Exception as e:
        print(f"An error occurred while reading the file: {e}")
        sys.exit(1)


def evaluate_grades(data):
    """
    Evaluates student grades and produces a comprehensive academic transcript.
    
    Tasks implemented:
    a) Check if all scores are percentage-based (0-100).
    b) Validate total weights (Total=100, Summative=40, Formative=60).
    c) Calculate the Final Grade and GPA using: GPA = (Total Grade / 100) * 5.0.
    d) Determine Pass/Fail status (>= 50% in BOTH categories).
    e) Identify failed formative assignments (< 50%) and select those with
       the highest weight eligible for resubmission.
    f) Print the official formatted academic transcript.
    """
    print("\n--- Processing Grades ---")
    
    if not data:
        print("Error: No assignment data provided for evaluation.")
        return

    # ---------------------------------------------------------
    # a) Check if all scores are percentage based (0-100)
    # ---------------------------------------------------------
    score_errors = []
    for item in data:
        score = item['score']
        if score < 0.0 or score > 100.0:
            score_errors.append(
                f"  - Assignment '{item['assignment']}': Score is {score} (must be between 0 and 100)."
            )

    if score_errors:
        print("\n[VALIDATION ERROR] Grade validation failed:")
        for err in score_errors:
            print(err)
        print("Aborting transcript generation due to invalid score data.\n")
        sys.exit(1)

    # ---------------------------------------------------------
    # b) Validate total weights (Total=100, Summative=40, Formative=60)
    # ---------------------------------------------------------
    formative_total_weight = 0.0
    summative_total_weight = 0.0
    unknown_groups = []

    for item in data:
        group_normalized = item['group'].strip().capitalize()
        weight = item['weight']

        if group_normalized == 'Formative':
            formative_total_weight += weight
        elif group_normalized == 'Summative':
            summative_total_weight += weight
        else:
            unknown_groups.append((item['assignment'], item['group']))

    if unknown_groups:
        print("\n[VALIDATION ERROR] Unrecognized assignment group(s) encountered:")
        for name, grp in unknown_groups:
            print(f"  - Assignment '{name}': '{grp}' (allowed: Formative, Summative)")
        print("Aborting transcript generation due to unrecognized categories.\n")
        sys.exit(1)

    total_weight = formative_total_weight + summative_total_weight
    weight_errors = []

    # Using tolerance of 0.01 for floating-point calculations
    if abs(formative_total_weight - 60.0) > 0.01:
        weight_errors.append(
            f"  - Formative assignments sum to {formative_total_weight:.2f}%, expected exactly 60.00%."
        )

    if abs(summative_total_weight - 40.0) > 0.01:
        weight_errors.append(
            f"  - Summative assignments sum to {summative_total_weight:.2f}%, expected exactly 40.00%."
        )

    if abs(total_weight - 100.0) > 0.01:
        weight_errors.append(
            f"  - Total assignment weights sum to {total_weight:.2f}%, expected exactly 100.00%."
        )

    if weight_errors:
        print("\n[VALIDATION ERROR] Weight validation failed:")
        for err in weight_errors:
            print(err)
        print("Aborting transcript generation due to weight discrepancies.\n")
        sys.exit(1)

    # ---------------------------------------------------------
    # c) Calculate the Final Grade and GPA
    # ---------------------------------------------------------
    # Each assignment's weighted score contribution = (score * weight) / 100.0
    formative_weighted_earned = 0.0
    summative_weighted_earned = 0.0

    assignment_details = []
    for item in data:
        group_normalized = item['group'].strip().capitalize()
        score = item['score']
        weight = item['weight']
        weighted_score = (score * weight) / 100.0

        if group_normalized == 'Formative':
            formative_weighted_earned += weighted_score
        else:
            summative_weighted_earned += weighted_score

        assignment_details.append({
            'assignment': item['assignment'],
            'group': group_normalized,
            'score': score,
            'weight': weight,
            'weighted_score': weighted_score
        })

    total_grade = formative_weighted_earned + summative_weighted_earned
    # GPA Formula: GPA = (Total Grade / 100) * 5.0
    final_gpa = (total_grade / 100.0) * 5.0

    # Category percentage scores
    formative_pct = (formative_weighted_earned / formative_total_weight) * 100.0
    summative_pct = (summative_weighted_earned / summative_total_weight) * 100.0

    # ---------------------------------------------------------
    # d) Determine Pass/Fail status (>= 50% in BOTH categories)
    # ---------------------------------------------------------
    formative_passed = formative_pct >= 50.0
    summative_passed = summative_pct >= 50.0
    student_passed = formative_passed and summative_passed
    final_status = "PASSED" if student_passed else "FAILED"

    # ---------------------------------------------------------
    # e) Resubmission Logic
    #    Resubmission is for failed formative assignment (< 50%) that carries
    #    the highest weight. If multiple failed formative assignments share
    #    the same highest weight, display all of them.
    # ---------------------------------------------------------
    failed_formatives = [
        item for item in assignment_details
        if item['group'] == 'Formative' and item['score'] < 50.0
    ]

    resubmission_candidates = []
    if failed_formatives:
        max_weight = max(item['weight'] for item in failed_formatives)
        resubmission_candidates = [
            item for item in failed_formatives
            if item['weight'] == max_weight
        ]

    # ---------------------------------------------------------
    # f) Print Official Academic Transcript
    # ---------------------------------------------------------
    print("=" * 76)
    print("               AFRICAN LEADERSHIP UNIVERSITY")
    print("                 OFFICIAL ACADEMIC TRANSCRIPT")
    print("=" * 76)
    print(f"{'Assignment Name':<38} {'Category':<11} {'Score':>7} {'Weight':>8} {'Weighted':>8}")
    print("-" * 76)

    for item in assignment_details:
        print(f"{item['assignment']:<38} {item['group']:<11} {item['score']:>6.1f}% {item['weight']:>7.1f}% {item['weighted_score']:>8.2f}")

    print("-" * 76)
    print("CATEGORY BREAKDOWN:")
    form_status = "MEETS REQUIREMENT (>= 50%)" if formative_passed else "BELOW REQUIREMENT (< 50%)"
    summ_status = "MEETS REQUIREMENT (>= 50%)" if summative_passed else "BELOW REQUIREMENT (< 50%)"

    print(f"  * Formative Assessments: Earned {formative_weighted_earned:.2f} / {formative_total_weight:.1f} pts ({formative_pct:.2f}%) -> {form_status}")
    print(f"  * Summative Assessments: Earned {summative_weighted_earned:.2f} / {summative_total_weight:.1f} pts ({summative_pct:.2f}%) -> {summ_status}")

    print("-" * 76)
    print("OVERALL PERFORMANCE:")
    print(f"  * Total Grade:  {total_grade:.2f} / 100.00")
    print(f"  * Final GPA:    {final_gpa:.2f} / 5.00")
    print(f"  * Final Status: {final_status}")

    print("-" * 76)
    print("RESUBMISSION ELIGIBILITY (Formative Only):")
    if resubmission_candidates:
        highest_wt = resubmission_candidates[0]['weight']
        print(f"  The following formative assignment(s) failed (< 50%) with the highest weight ({highest_wt:.1f}%):")
        for cand in resubmission_candidates:
            print(f"    - {cand['assignment']} (Score: {cand['score']:.1f}%, Weight: {cand['weight']:.1f}%)")
    else:
        print("  None. No failed formative assignments qualify for resubmission.")

    print("=" * 76)
    print("\nTranscript generation complete.\n")


if __name__ == "__main__":
    # If a filename argument was provided on the command line, use it;
    # otherwise prompt the user interactively (standard template behavior).
    if len(sys.argv) > 1:
        target_file = sys.argv[1]
        course_data = load_csv_data(target_file)
    else:
        course_data = load_csv_data()

    evaluate_grades(course_data)
