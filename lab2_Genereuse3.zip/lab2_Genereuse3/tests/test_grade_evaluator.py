#!/usr/bin/env python3
"""
Comprehensive automated test suite for ALU Transcript Generator (Lab 2).
Tests all functional requirements, validations, and edge cases.
"""

import os
import sys
import tempfile
import unittest

# Add lab directory to path
current_dir = os.path.dirname(os.path.abspath(__file__))
parent_dir = os.path.dirname(current_dir)
sys.path.insert(0, parent_dir)

import importlib
evaluator = importlib.import_module("grade-evaluator")


class TestGradeEvaluator(unittest.TestCase):

    def setUp(self):
        self.valid_data = [
            {'assignment': 'Quiz', 'group': 'Formative', 'score': 85.0, 'weight': 20.0},
            {'assignment': 'Group Exercise', 'group': 'Formative', 'score': 40.0, 'weight': 20.0},
            {'assignment': 'Functions and Debugging Lab', 'group': 'Formative', 'score': 45.0, 'weight': 20.0},
            {'assignment': 'Midterm Project - Simple Calculator', 'group': 'Summative', 'score': 70.0, 'weight': 20.0},
            {'assignment': 'Final Project - Text-Based Game', 'group': 'Summative', 'score': 60.0, 'weight': 20.0}
        ]

    def test_valid_grades_calculations(self):
        """Test calculations on the default provided dataset."""
        # Formative: 85*0.2 + 40*0.2 + 45*0.2 = 17 + 8 + 9 = 34.0 out of 60 (56.67%)
        # Summative: 70*0.2 + 60*0.2 = 14 + 12 = 26.0 out of 40 (65.00%)
        # Total Grade = 34.0 + 26.0 = 60.0
        # GPA = (60.0 / 100) * 5.0 = 3.00
        # Final Status = PASSED
        # Resubmission: Group Exercise and Functions and Debugging Lab (both failed with highest weight 20)
        
        # Capture stdout
        import io
        from contextlib import redirect_stdout
        
        f = io.StringIO()
        with redirect_stdout(f):
            evaluator.evaluate_grades(self.valid_data)
        output = f.getvalue()
        
        self.assertIn("Total Grade:  60.00 / 100.00", output)
        self.assertIn("Final GPA:    3.00 / 5.00", output)
        self.assertIn("Final Status: PASSED", output)
        self.assertIn("Group Exercise", output)
        self.assertIn("Functions and Debugging Lab", output)

    def test_invalid_score_range_exits(self):
        """Test that scores > 100 or < 0 cause system exit."""
        invalid_data_high = [
            {'assignment': 'Quiz', 'group': 'Formative', 'score': 105.0, 'weight': 20.0},
            {'assignment': 'Lab 1', 'group': 'Formative', 'score': 50.0, 'weight': 40.0},
            {'assignment': 'Exam', 'group': 'Summative', 'score': 80.0, 'weight': 40.0}
        ]
        with self.assertRaises(SystemExit):
            evaluator.evaluate_grades(invalid_data_high)

        invalid_data_neg = [
            {'assignment': 'Quiz', 'group': 'Formative', 'score': -5.0, 'weight': 20.0},
            {'assignment': 'Lab 1', 'group': 'Formative', 'score': 50.0, 'weight': 40.0},
            {'assignment': 'Exam', 'group': 'Summative', 'score': 80.0, 'weight': 40.0}
        ]
        with self.assertRaises(SystemExit):
            evaluator.evaluate_grades(invalid_data_neg)

    def test_invalid_weight_distribution_exits(self):
        """Test that weights not summing to Formative 60, Summative 40, Total 100 exit."""
        # Summative 50, Formative 50 (Total 100, but categories wrong)
        wrong_categories = [
            {'assignment': 'Lab', 'group': 'Formative', 'score': 80.0, 'weight': 50.0},
            {'assignment': 'Exam', 'group': 'Summative', 'score': 80.0, 'weight': 50.0}
        ]
        with self.assertRaises(SystemExit):
            evaluator.evaluate_grades(wrong_categories)

        # Total not 100
        wrong_total = [
            {'assignment': 'Lab', 'group': 'Formative', 'score': 80.0, 'weight': 60.0},
            {'assignment': 'Exam', 'group': 'Summative', 'score': 80.0, 'weight': 30.0}
        ]
        with self.assertRaises(SystemExit):
            evaluator.evaluate_grades(wrong_total)

    def test_failing_status(self):
        """Test that scoring < 50% in either category results in FAILED status."""
        import io
        from contextlib import redirect_stdout

        failing_formative = [
            {'assignment': 'Quiz', 'group': 'Formative', 'score': 30.0, 'weight': 60.0},
            {'assignment': 'Exam', 'group': 'Summative', 'score': 90.0, 'weight': 40.0}
        ]
        f = io.StringIO()
        with redirect_stdout(f):
            evaluator.evaluate_grades(failing_formative)
        output = f.getvalue()
        self.assertIn("Final Status: FAILED", output)
        self.assertIn("BELOW REQUIREMENT (< 50%)", output)

    def test_resubmission_highest_weight_tie_and_single(self):
        """Test resubmission selects only the highest weight failed formative, or all tied."""
        import io
        from contextlib import redirect_stdout

        # One failed with weight 30, one failed with weight 10 -> only weight 30 should be eligible
        different_weights = [
            {'assignment': 'Quiz 1', 'group': 'Formative', 'score': 40.0, 'weight': 10.0},
            {'assignment': 'Quiz 2', 'group': 'Formative', 'score': 45.0, 'weight': 20.0},
            {'assignment': 'Quiz 3', 'group': 'Formative', 'score': 48.0, 'weight': 30.0},
            {'assignment': 'Exam', 'group': 'Summative', 'score': 70.0, 'weight': 40.0}
        ]
        f = io.StringIO()
        with redirect_stdout(f):
            evaluator.evaluate_grades(different_weights)
        output = f.getvalue()
        self.assertIn("Quiz 3", output)
        # Quiz 1 and Quiz 2 have lower weights, so shouldn't be in the resubmission list
        self.assertNotIn("- Quiz 1", output)
        self.assertNotIn("- Quiz 2", output)


if __name__ == "__main__":
    unittest.main()
